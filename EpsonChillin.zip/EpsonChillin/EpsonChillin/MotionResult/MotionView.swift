//
//  MotionView.swift
//  EpsonChillin
//
//  Created by 이승현 on 6/22/24.
//

import UIKit
import SnapKit

class MotionResultView: BaseView {

    
    
    override func configureView() {

    }
    
    override func setConstraints() {
        
    }
    
}
